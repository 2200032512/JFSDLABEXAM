package com.klef.jsfsd.exam;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import java.util.List;

public class ClientDemo {
    public static void main(String[] args) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        // Insert records
        Customer customer1 = new Customer();
        customer1.setName("Alice");
        customer1.setEmail("alice@example.com");
        customer1.setAge(30);
        customer1.setLocation("New York");

        Customer customer2 = new Customer();
        customer2.setName("Bob");
        customer2.setEmail("bob@example.com");
        customer2.setAge(40);
        customer2.setLocation("Los Angeles");

        session.save(customer1);
        session.save(customer2);

        transaction.commit();

        // Apply Criteria Queries
        Criteria criteria = session.createCriteria(Customer.class);
        criteria.add(Restrictions.lt("age", 35)); // Fetch customers aged less than 35
        List<Customer> results = criteria.list();

        for (Customer customer : results) {
            System.out.println(customer.getName() + " - " + customer.getAge());
        }

        session.close();
    }
}
